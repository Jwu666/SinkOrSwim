package com.sos.sinkorswim.Text;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class messagesort {
    public static void messagesort_1() {
        Scanner sc = new Scanner(System.in);
        String line = sc.nextLine();
        String[] split = line.split(" ");
        List<String> list = Arrays.asList(split);
        for (int i = 0; i < list.size(); i++) {
            String s = list.get(i);
            if ("".equals(s)) {
                list.remove(i);
            }
        }
        int[] ints = new int[list.size()];
        for (int i = 0; i < ints.length; i++) {
            ints[i] = Integer.parseInt(list.get(i));
        }

        for (int i = 1; i < ints.length; i++) {
            for (int j = 0; j < i; j++) {
                if (ints[i] <= ints[j]) {
                    int temp = ints[i];
                    for (int k = i; k >= j && k > 0; k--) {
                        ints[k] = ints[k - 1];
                    }
                    ints[j] = temp;
                }
            }
        }

        for (int i = 0; i < ints.length - 1; i++) {
            int anInt = ints[i];
            System.out.print(String.format("%d ", anInt));
        }
        System.out.println(ints[ints.length - 1]);
    }

    public static void messagesort_2() {
        Scanner sc = new Scanner(System.in);
        String line = sc.nextLine();
        String[] split = line.split(" ");
        List<String> list = Arrays.asList(split);
        for (int i = 0; i < list.size(); i++) {
            String s = list.get(i);
            if ("".equals(s)) {
                list.remove(i);
            }
        }
        int[] ints = new int[list.size()];
        for (int i = 0; i < ints.length; i++) {
            ints[i] = Integer.parseInt(list.get(i));
        }

        int temp = 0;
        for (int i = 0; i < ints.length; i++) {
            temp = i;
            for (int j = i + 1; j < ints.length; j++) {
                if (ints[j] < ints[temp]) {
                    temp = j;
                }
            }

            if (ints[i] > ints[temp]) {
                ints[i] = ints[temp] + ints[i];
                ints[temp] = ints[i] - ints[temp];
                ints[i] = ints[i] - ints[temp];
            }
        }

        for (int i = 0; i < ints.length - 1; i++) {
            int anInt = ints[i];
            System.out.print(String.format("%d ", anInt));
        }
        System.out.println(ints[ints.length - 1]);
    }
    public static void messagesort_3() {
        Scanner sc = new Scanner(System.in);
        String line = sc.nextLine();
        String[] split = line.split(" ");
        List<String> list = Arrays.asList(split);
        for (int i = 0; i < list.size(); i++) {
            String s = list.get(i);
            if (" ".equals(s)) {
                list.remove(i);
            }
        }
        int[] ints = new int[list.size()];
        for (int i = 0; i < ints.length; i++) {
            ints[i] = Integer.parseInt(list.get(i));
        }

        for (int i = 0; i < ints.length; i++) {
            for (int j = 1; j < ints.length-i; j++) {
                int temp = ints[j-1];
                if (temp > ints[j]) {
                    ints[j-1]=ints[j];
                    ints[j] = temp;
                }
            }
        }

        for (int i = 0; i < ints.length-1; i++) {
            int anInt = ints[i];
            System.out.print(String.format("%d ", anInt));
        }
        System.out.println(ints[ints.length -1]);
    }

    public class SimplePing implements Runnable {
        private final Object mEndLock = new Object();
        private boolean IsEnd = false;

        private int arrivedCount = 0;

        private int Count;
        private int TimeOut;
        private String Name;

        private int mEndCount;
        private String mIp = null;
        private float mLossRate = 1f;
        private float mDelay = 0;


        public SimplePing(String name, int count, int timeOut) {
            Count = mEndCount = count;
            TimeOut = timeOut;
            Name = name;
            for (int i = 0; i < mEndCount; i++) {
                Thread thread = new Thread(this);
                thread.setDaemon(true);
                thread.start();
            }
            if (!IsEnd) {
                try {
                    synchronized (mEndLock) {
                        mEndLock.wait();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        private void setEnd(boolean isArrived, long delay, String ip) {
            synchronized (mEndLock) {
                Count--;
                if (isArrived) {
                    arrivedCount++;
                    mDelay = (mDelay + delay) / 2f;
                    if (ip != null)
                        mIp = ip;
                }
            }
            if (Count == 0)
                setEnd();
        }

        private void setEnd() {
            mLossRate = (mEndCount - arrivedCount) / mEndCount;

            IsEnd = true;
            synchronized (mEndLock) {
                mEndLock.notifyAll();
            }
        }

        @Override
        public void run() {
            long delay = 0;
            boolean isArrived = false;
            String ip = null;
            try {
                long startTime = System.currentTimeMillis();
                InetAddress address = InetAddress.getByName(Name);
                isArrived = address.isReachable(TimeOut);
                delay = System.currentTimeMillis() - startTime;
                ip = address.getHostAddress();
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                setEnd(isArrived, delay, ip);
            }
        }

        public String getIp() {
            return mIp;
        }

        public float getLossRate() {
            return mLossRate;
        }

        public float getDelay() {
            return mDelay;
        }

        public boolean getIsSucceed() {
            return arrivedCount > 0;
        }
    }
}
