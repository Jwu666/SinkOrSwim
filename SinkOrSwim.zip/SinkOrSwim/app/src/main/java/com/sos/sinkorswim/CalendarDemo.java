package com.sos.sinkorswim;

import java.util.*;

public class CalendarDemo extends GregorianCalendar {
    public static void Clone() {
        // create new calendar at specific date.
        Calendar cal = new GregorianCalendar(2008, 05, 20);

        // print date for default value
        System.out.println("Past calendar : " + cal.getTime());

        // create a clone of first cal
        Calendar cal2 = (Calendar) cal.clone();

        // display the copy
        System.out.println("Cloned calendar : " + cal2.getTime());
    }

    public static void GetTimeinMillis() throws InterruptedException {
        // create a calendar
        Calendar cal = Calendar.getInstance();

        // print current time in milliseconds
        System.out.println("Current time is : " + cal.getTimeInMillis());

        // add a delay of 2 seconds
        Thread.sleep(2000);

        // create a new calendar
        Calendar cal2 = Calendar.getInstance();

        // print the next time in milliseconds
        long d = cal2.getTimeInMillis();
        System.out.println("Next time is : " + d);
    }

    public static void GetTimeZone() {
        // create a calendar
        Calendar cal = Calendar.getInstance();

        // get the time zone
        TimeZone tz = cal.getTimeZone();

        // print the time zone name for this calendar
        System.out.println("The time zone is :" + tz.getDisplayName());
    }

    public static void Hashcode() {
        // create a calendar
        Calendar cal = Calendar.getInstance();

        // display current calendar
        System.out.println("The current calendar shows: " + cal.getTime());

        // get the hash code and print it
        int i = cal.hashCode();
        System.out.println("A hash code for this calendar is: " + i);
    }

    public static void InternalGet() {
        // create a new calendar
        CalendarDemo cal = new CalendarDemo();

        // print the current date
        System.out.println("The current date is : " + cal.getTime());

        // use internal get to get the year
        System.out.println("Year is : " + cal.internalGet(YEAR));

        // use internal get to get the month
        System.out.println("Month is : " + cal.internalGet(MONTH));
    }

    public static void isLinient() {
        // create a calendar
        Calendar cal = Calendar.getInstance();

        // displays the current calendar
        System.out.println("Current Date and Time is " + cal.getTime());

        // tells whether date/time interpretation is lenient.
        boolean b = cal.isLenient();
        System.out.println("Interpretation is lenient: " + b);
    }
    public static void GetActualMaximum() {
        // create a calendar
        Calendar cal = Calendar.getInstance();

        // get the maximum value that year field can have
        int i = cal.getActualMaximum(Calendar.YEAR);
        System.out.println("Maximum year:" + i);

        // get the maximum value that month field can have
        int a = cal.getActualMaximum(Calendar.MONTH);
        System.out.println("Maximum month:" + a);
    }

    public static void GetActualMinimum() {
        // create a calendar
        Calendar cal = Calendar.getInstance();

        // return the minimum value that the year field could have
        int i = cal.getActualMinimum(Calendar.YEAR);
        System.out.println("Minimum Year :"+ i);

        // returns the minimum value that the month field could have
        int a = cal.getActualMinimum(Calendar.MONTH);
        System.out.println("Minimum month :"+ a);
    }

    public static void Equals() {
        // create two calendars
        Calendar cal = Calendar.getInstance();

        // specify a date for one of them
        Calendar cal2 = new GregorianCalendar(2011, 04, 29);

        // compare the two calendars.
        boolean b = cal.equals(cal2);

        // print result
        System.out.println("Calendars are equal :" + b);
    }

    public static void CompareTo() {
        // create two calendar at the different dates
        Calendar cal1 = new GregorianCalendar(2015, 8, 15);
        Calendar cal2 = new GregorianCalendar(2008, 1, 02);

        // compare the time values represented by two calendar objects.
        int i = cal1.compareTo(cal2);

        // return positive value if equals else return negative value
        System.out.println("The result is :" + i);

        // compare again but with the two calendars swapped
        int j = cal2.compareTo(cal1);

        // return positive value if equals else return negative value
        System.out.println("The result is :" + j);
    }

    public static void ComputeTime() {
        // create a new calendar
        CalendarDemo cal = new CalendarDemo();

        // print the current date
        System.out.println("The current date is : " + cal.getTime());

        // clear the calendar
        cal.clear();

        // set a new year and call computeTime()
        cal.set(GregorianCalendar.YEAR, 1998);
        cal.computeTime();

        // print the current date
        System.out.println("New date is : " + cal.getTime());
    }

    public static void CalendarGetDisplayNameEx() {
        // create objects of locale class
        Locale object1 = new Locale("GERMAN", "Germany");
        Locale object2 = new Locale("FRENCH", "France");
        System.out.println("Object1 is : " + object1);
        System.out.println("Object2 is : " + object2);

        // get the display name for object1
        String objName = object1.getDisplayName();

        // print the results
        System.out.println("Name for object1 : " + objName);

        // get the display name for object2
        objName = object2.getDisplayName();
        System.out.println("Name for object2 : " + objName);

    }

    public static void CalendarDemo(){
        // create calendar and locale
        Calendar now = Calendar.getInstance();
        Locale locale = Locale.getDefault();

        // call the getdisplaynames method
        Map< String, Integer> representations =
                now.getDisplayNames(Calendar.DAY_OF_WEEK, Calendar.LONG, locale);
        NavigableMap< String, Integer> navMap =
                new TreeMap< String, Integer>(representations);

        // print the results
        System.out.printf("Whole list:%n%s%n", navMap);
    }

    public static void GetAvailableLocals() {
        // create an object of locale class
        Locale[] array = new Locale[10];

        // get available locales and assign them to array
        array = Locale.getAvailableLocales();

        // print the results
        System.out.println("The first 10 locales installed are :-\n");
        for (int i = 0; i < 10; i++) {
            System.out.println(array[i].getISO3Country());
        }
    }
}
