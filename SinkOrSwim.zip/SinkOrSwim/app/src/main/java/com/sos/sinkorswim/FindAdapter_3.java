package com.sos.sinkorswim;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.DateFormat;
import java.time.LocalTime;
import java.util.Locale;
import java.util.Scanner;
import java.util.Arrays;

public class FindAdapter_3 {
    public static void Loc_date() {

        LocalDate today = LocalDate.now();
        int year = today.getYear();
        int month = today.getMonthValue();
        int day = today.getDayOfMonth();
        System.out.printf("Year : %d  Month : %d  day : %d  %n", year, month, day);

        LocalDate dateOfBirth = LocalDate.of(2000, 05, 27);
        System.out.println("Your Date of birth is : " + dateOfBirth);

        LocalDate dateOfBirth1 = LocalDate.of(2010, 01, 14);
        MonthDay birthday = MonthDay.of(dateOfBirth.getMonth(), dateOfBirth1.getDayOfMonth());
        MonthDay currentMonthDay = MonthDay.from(today);
        if (currentMonthDay.equals(birthday)) {
            System.out.println("Many Many happy returns of the day !!");
        } else {
            System.out.println("Sorry, today is not your birthday");
        }

        LocalTime time = LocalTime.now();
        System.out.println("local time now : " + time);

        LocalDate previousYear = today.minus(1, ChronoUnit.YEARS);
        System.out.println("Date before 1 year : " + previousYear);
        LocalDate nextYear = today.plus(1, ChronoUnit.YEARS);
        System.out.println("Date after 1 year : " + nextYear);

        Clock clock = Clock.systemUTC();
        System.out.println("Clock : " + clock);

        ZoneId america = ZoneId.of("America/New_York");
        LocalDateTime localtDateAndTime = LocalDateTime.now();
        ZonedDateTime dateAndTimeInNewYork = ZonedDateTime.of(localtDateAndTime, america);
        System.out.println("Current date and time in a particular timezone : " + dateAndTimeInNewYork);

        YearMonth currentYearMonth = YearMonth.now();
        System.out.printf("Days in month year %s: %d%n", currentYearMonth, currentYearMonth.lengthOfMonth());
        YearMonth creditCardExpiry = YearMonth.of(2019, Month.JANUARY);
        System.out.printf("Your credit card expires on %s %n", creditCardExpiry);

        LocalDate java8Release = LocalDate.of(2019, Month.MARCH, 15);
        Period periodToNextJavaRelease = Period.between(today, java8Release);
        System.out.println("Months left between today and Java 8 release : "
                + periodToNextJavaRelease.getMonths());

        LocalDateTime datetime = LocalDateTime.of(2019, Month.MARCH, 15, 1, 50);
        ZoneOffset offset = ZoneOffset.of("+05:30");
        OffsetDateTime date = OffsetDateTime.of(datetime, offset);
        System.out.println("Date and Time with timezone offset in Java : " + date);

        String dayAfterTommorrow = "20190316";
        LocalDate formatted = LocalDate.parse(dayAfterTommorrow,
                DateTimeFormatter.BASIC_ISO_DATE);
        System.out.printf("Date generated from String %s is %s %n",
                dayAfterTommorrow, formatted);

        LocalDateTime arrivalDate = LocalDateTime.now();
        try {
            DateTimeFormatter format = DateTimeFormatter.ofPattern("MMM dd yyyy  hh:mm a");
            String landing = arrivalDate.format(format);
            System.out.printf("Arriving at :  %s %n", landing);
        } catch (DateTimeException ex) {
            System.out.printf("%s can't be formatted!%n", arrivalDate);
            ex.printStackTrace();
        }
    }

    public static class DateDifferent {
        public static void Date() {

            String startTime = "2019-03-18 01:31:58";
            String stopTime = "2019-03-17 04:36:22";
            String time2 = "2019-3-17 20:22:22";

            Date date = new Date();
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            System.out.println("TimeNow: " + format.format(date));
            Date d1;
            Date d2;
            Date d3;
            long diff = 0;

            try {
                d1 = format.parse(startTime);
                d2 = format.parse(stopTime);
                d3 = format.parse(time2);

                diff = date.getTime() - d1.getTime();
                diff = date.getTime() - d2.getTime();
                diff = date.getTime() - d3.getTime();
            } catch (ParseException e) {
                e.printStackTrace();
            }

            //long diffSeconds = diff / 1000;
            long diffMinutes = diff / (1000 * 60);
            long diffHours = diff / (1000 * 60 * 60);
            long diffDays = diff / (1000 * 60 * 60 * 24);
            //System.out.println(startTime + " " +Math.abs(diffSeconds) + " Second");
            System.out.println(startTime + " " + Math.abs(diffMinutes) + " Minutes");
            System.out.println(stopTime + " " + Math.abs(diffHours) + " Hours");
            System.out.println(time2 + " " + Math.abs(diffDays) + " Days");
            System.out.println(format.format(date) + " " + " Just Now");

        }
    }

    public static void sort() {
        // initializing unsorted byte array
        byte bArr[] = {10, 7, 4, 37, 29};

        // let us print all the elements available in list
        for (byte number : bArr) {
            System.out.println("Number = " + number);
        }

        // sorting array from index 1 to 4
        Arrays.sort(bArr, 1, 4);

        // let us print all the elements available in list
        System.out.println("Byte array with some sorted values(1 to 4) is:");
        for (byte number : bArr) {
            System.out.println("Number = " + number);
        }
    }

    public static void ArrayDemo() {

        // initializing unsorted byte array
        byte bArr[] = {10, 2, 7, 35};

        // let us print all the elements available in list
        for (byte number : bArr) {
            System.out.println("Number = " + number);
        }

        // sorting array
        Arrays.sort(bArr);

        // let us print all the elements available in list
        System.out.println("The sorted byte array is:");
        for (byte number : bArr) {
            System.out.println("Number = " + number);
        }
    }

    public static void chardemo() {

        // initializing unsorted char array
        char cArr[] = {'r','q','s','p'};

        // let us print all the values available in list
        for (char value : cArr) {
            System.out.println("Value = " + value);
        }

        // sorting array
        Arrays.sort(cArr);

        // let us print all the values available in list
        System.out.println("The sorted char array is:");
        for (char value : cArr) {
            System.out.println("Value = " + value);
        }
    }
}