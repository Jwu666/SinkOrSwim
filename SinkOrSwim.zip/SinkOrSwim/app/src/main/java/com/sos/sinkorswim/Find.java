package com.sos.sinkorswim;

public class Find {
    private int imageId;
    public Find(int id){
        imageId=id;
    }
    public int getImageId(){
        return imageId;
    }
}
