package com.sos.sinkorswim.Text;

import android.graphics.Bitmap;

public class Photo_item {
    public Bitmap bitmap;

    public Photo_item(Bitmap bitmap1) {
        bitmap = bitmap1;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }
}


