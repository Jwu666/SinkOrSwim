package com.sos.sinkorswim;

import android.widget.ImageView;

public class Message {
    private int ImageId;
    public Message(int ID){
        ImageId=ID;
    }
    public int GetID(){
        return ImageId;
    }
}
