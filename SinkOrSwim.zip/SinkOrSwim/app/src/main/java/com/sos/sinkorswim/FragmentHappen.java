package com.sos.sinkorswim;

import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sos.sinkorswim.R;

import java.util.ArrayList;
import java.util.List;

public class FragmentHappen extends Fragment {

    public static List<EventBean> eventBeanList = new ArrayList<>();
    private RecyclerView recycHappen;
    private LinearLayoutManager layoutManager;
    private EventAdapter eventAdapter;

    static String str_1 = "The early bird catches the worm，Lie down before 23:50 and punch in at 6:30!Full of vitality day!!";
    static String str_2 = "October 28, 2016 - This article mainly introduces the drop-down RefreshLayout of Android RefreshLayout in detail, which has certain reference value. Interested parties can refer to the drop-down refresh function in the project, but...";

    static {
        List<Uri> list_1 = new ArrayList<>();
        for (int n = 0; n < 2; n++) {
//            String strUri = String.format("content://media/external/images/media/31422");
            list_1.add(Uri.parse(MainActivity.resourceIdToUri(MyApplication.getContext(), R.drawable.ic_header_71 ).toString()));
            list_1.add(Uri.parse(MainActivity.resourceIdToUri(MyApplication.getContext(), R.drawable.ic_header_72 ).toString()));
            list_1.add(Uri.parse(MainActivity.resourceIdToUri(MyApplication.getContext(), R.drawable.ic_header_73 ).toString()));
            list_1.add(Uri.parse("content://media/external/images/media/860774"));
        }

        List<Uri> list_2 = new ArrayList<>();
        list_2.add(Uri.parse(MainActivity.resourceIdToUri(MyApplication.getContext(), R.drawable.ic_header_71 ).toString()));


        EventBean eventBean_1 = new EventBean(MainActivity.resourceIdToUri(MyApplication.getContext(), R.drawable.ic_header_71 ).toString(),"Flying penguins", str_1, "10：24am", true, list_1);
        EventBean eventBean_2 = new EventBean(MainActivity.resourceIdToUri(MyApplication.getContext(), R.drawable.ic_header_72 ).toString(), "Fat flying pigs", str_2, "12：24am ", true, list_2);
        EventBean eventBean_3 = new EventBean(MainActivity.resourceIdToUri(MyApplication.getContext(), R.drawable.ic_header_73 ).toString(),"Flying penguins", str_1, "just now", true, list_1);

        eventBeanList.add(eventBean_1);
        eventBeanList.add(eventBean_2);
        eventBeanList.add(eventBean_3);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_happen, container, false );
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);



        eventAdapter = new EventAdapter(eventBeanList);

        recycHappen = getActivity().findViewById(R.id.recyclerview_happen);
        layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);

        recycHappen.setLayoutManager(layoutManager);
        recycHappen.setAdapter(eventAdapter);


    }
}
